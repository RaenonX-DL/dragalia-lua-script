local m = dofile(scriptPath() .. "script/DefaultConfigs.lua")

-- Main

m.DimensionWidth = 1080

-- Action Specific Configurations

m.PostgameClickCheckWaitSeconds = 1.5

return m